"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, Video, VideoOff, Monitor, Users } from "lucide-react"

interface VideoPanelProps {
  roomCode: string
}

export function VideoPanel({ roomCode }: VideoPanelProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const [localStream, setLocalStream] = useState<MediaStream | null>(null)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    startLocalStream()
    return () => {
      if (localStream) {
        localStream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  const startLocalStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      })
      setLocalStream(stream)
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream
      }
      // In a real implementation, we would initialize WebRTC connection here
      // For demo, we'll simulate a connected state after 2 seconds
      setTimeout(() => setIsConnected(true), 2000)
    } catch (err) {
      setError("Unable to access camera/microphone. Please grant permissions.")
      console.error("Error accessing media devices:", err)
    }
  }

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = isMuted
      })
      setIsMuted(!isMuted)
    }
  }

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach((track) => {
        track.enabled = isVideoOff
      })
      setIsVideoOff(!isVideoOff)
    }
  }

  const shareScreen = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
      })
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = screenStream
      }
      screenStream.getVideoTracks()[0].onended = () => {
        if (localVideoRef.current && localStream) {
          localVideoRef.current.srcObject = localStream
        }
      }
    } catch (err) {
      console.error("Error sharing screen:", err)
    }
  }

  return (
    <div className="h-full flex flex-col bg-muted/30">
      {/* Video Container */}
      <div className="flex-1 p-2 flex flex-col gap-2">
        {/* Remote Video (Main) */}
        <div className="flex-1 relative bg-muted rounded-lg overflow-hidden">
          {isConnected ? (
            <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">Waiting for participant...</p>
              </div>
            </div>
          )}
        </div>

        {/* Local Video (Picture-in-Picture) */}
        <div className="relative h-32 bg-muted rounded-lg overflow-hidden">
          {error ? (
            <div className="absolute inset-0 flex items-center justify-center p-2">
              <p className="text-xs text-destructive text-center">{error}</p>
            </div>
          ) : (
            <>
              <video ref={localVideoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
              {isVideoOff && (
                <div className="absolute inset-0 bg-muted flex items-center justify-center">
                  <VideoOff className="h-8 w-8 text-muted-foreground" />
                </div>
              )}
              <div className="absolute bottom-2 left-2 text-xs bg-background/80 px-2 py-1 rounded">You</div>
            </>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="p-3 border-t border-border flex items-center justify-center gap-2">
        <Button variant={isMuted ? "destructive" : "secondary"} size="icon" onClick={toggleMute}>
          {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
        </Button>
        <Button variant={isVideoOff ? "destructive" : "secondary"} size="icon" onClick={toggleVideo}>
          {isVideoOff ? <VideoOff className="h-4 w-4" /> : <Video className="h-4 w-4" />}
        </Button>
        <Button variant="secondary" size="icon" onClick={shareScreen}>
          <Monitor className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
